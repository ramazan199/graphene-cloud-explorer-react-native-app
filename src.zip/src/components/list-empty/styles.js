import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        marginTop: '50%'
    },

    container2: {
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        marginTop: '10%'
    },
    text: {
        color: '#B0C0D0',
        fontSize: 14,
        marginTop: 12,
        textAlign: 'center',
    }
})