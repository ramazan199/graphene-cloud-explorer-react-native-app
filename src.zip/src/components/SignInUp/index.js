import React, { useEffect } from 'react';
import * as WebBrowser from 'expo-web-browser';
import { makeRedirectUri, useAuthRequest, useAutoDiscovery } from 'expo-auth-session';
import { Button, Text, View } from 'react-native';
import axios from 'axios'; // For token exchange requests
import * as SecureStore from 'expo-secure-store';
WebBrowser.maybeCompleteAuthSession();

export default function SignInUp() {
  const discovery = useAutoDiscovery('https://cloudkeycloak.duckdns.org/realms/cloud');

  const [request, result, promptAsync] = useAuthRequest(
    {
      clientId: 'cloud-mobile-app',
      redirectUri: makeRedirectUri({
        scheme: 'com.cloudapp',
      }) + 'redirect',
      scopes: ['openid', 'profile'],
      usePKCE: true, // Enables automatic PKCE handling
    },
    discovery
  );

  const exchangeCodeForToken = async (code, codeVerifier) => {
    try {
      const response = await axios.post(
        'https://cloudkeycloak.duckdns.org/realms/cloud/protocol/openid-connect/token',
        new URLSearchParams({
          client_id: 'cloud-mobile-app',
          code: code,
          redirect_uri: makeRedirectUri({ scheme: 'com.cloudapp' }) + 'redirect',
          grant_type: 'authorization_code',
          code_verifier: codeVerifier
        }).toString(),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
        }
      );

      console.log('Token Response:', response.data);
      saveTokens(response.data.access_token, response.data.refresh_token);
    } catch (error) {
      console.error('Token exchange failed:', {
        status: error.response?.status,
        data: error.response?.data,
        headers: error.response?.headers,
      });
    }
  };

  // Function to save tokens
  const saveTokens = async (accessToken, refreshToken) => {
    await SecureStore.setItemAsync('accessToken', accessToken);
    await SecureStore.setItemAsync('refreshToken', refreshToken);
  };

  useEffect(() => {
    if (result?.type === 'success') {
      const { code } = result.params;
      const codeVerifier = request?.codeVerifier;
      exchangeCodeForToken(code, codeVerifier);
    }
  }, [result]);

  function register() {
    console.log("dsd");
  }

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Button title="Login!" disabled={!request} onPress={() => promptAsync()} />
      {/* <Button title="Register!" disabled={!request} onPress={() => register()} /> */}

      {result && <Text>{JSON.stringify(result, null, 2)}</Text>}
    </View>
  );
}
