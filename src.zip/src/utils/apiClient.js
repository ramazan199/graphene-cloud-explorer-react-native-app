import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import jwtDecode from 'jwt-decode';

// Create Axios instance
const apiClient = axios.create({
    baseURL: 'http://proxy.cloudservices.agency:5050',
});

// Function to check if a token is expired
const isTokenExpired = (token) => {
    const decoded = jwtDecode(token);
    return decoded.exp * 1000 < Date.now(); // `exp` is in seconds, so convert to milliseconds
};

// Function to refresh the access token
const refreshAccessToken = async () => {
    const refreshToken = await SecureStore.getItemAsync('refreshToken');

    try {
        const response = await axios.post(
            'https://cloudkeycloak.duckdns.org/realms/cloud/protocol/openid-connect/token',
            new URLSearchParams({
                client_id: 'cloud-mobile-app',
                grant_type: 'refresh_token',
                refresh_token: refreshToken,
            }).toString(),
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
            }
        );

        const { access_token, refresh_token } = response.data;

        // Save the new tokens
        await SecureStore.setItemAsync('accessToken', access_token);
        await SecureStore.setItemAsync('refreshToken', refresh_token);

        return access_token; // Return the new access token
    } catch (error) {
        console.error('Failed to refresh token:', error);
        throw error; // Handle refresh failure (e.g., log out the user)
    }
};

// Request Interceptor: Attach token and check for expiry
apiClient.interceptors.request.use(async (config) => {
    let accessToken = await SecureStore.getItemAsync('accessToken');

    if (accessToken) {
        // Check if the token is expired
        if (isTokenExpired(accessToken)) {
            try {
                accessToken = await refreshAccessToken(); // Refresh token if expired
            } catch (error) {
                console.error('Failed to refresh token during request:', error);
                throw error; // Handle token refresh failure
            }
        }

        // Attach the valid token to the request
        config.headers.Authorization = `Bearer ${accessToken}`;
    }

    return config;
}, (error) => {
    return Promise.reject(error);
});

// Response Interceptor: Handle 401 errors
apiClient.interceptors.response.use(
    (response) => response, // Pass through valid responses
    async (error) => {
        const originalRequest = error.config;

        // Handle 401 Unauthorized responses
        if (error.response?.status === 401 && !originalRequest._retry) {
            originalRequest._retry = true; // Mark this request as retried

            try {
                const accessToken = await refreshAccessToken(); // Refresh token on 401
                originalRequest.headers.Authorization = `Bearer ${accessToken}`;
                return apiClient(originalRequest); // Retry the original request with the new token
            } catch (refreshError) {
                console.error('Failed to refresh token after 401:', refreshError);
                throw refreshError; // Handle refresh failure
            }
        }

        return Promise.reject(error);
    }
);

export default apiClient;
