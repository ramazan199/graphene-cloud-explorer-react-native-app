import React, { useEffect, useState } from 'react';
import { Button, View, Alert, StyleSheet } from 'react-native';
import { useStripe, StripeProvider } from '@stripe/stripe-react-native';

export default function PaymentScreen() {
    const { initPaymentSheet, presentPaymentSheet } = useStripe();
    const [clientSecret, setClientSecret] = useState(null);

    // Fetch the PaymentIntent client secret from your backend
    useEffect(() => {
        fetch('http://192.168.0.100:8080/api/payment/intent', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ planName: "DIAMOND" }), // Amount in cents ($50.00)
        })
            .then((response) => response.json())
            .then((data) => {
                setClientSecret(data.clientSecret);
                initializePaymentSheet(data.clientSecret);
            })
            .catch((error) => {
                console.error('Error fetching client secret:', error);
            });
    }, []);

    // Initialize the PaymentSheet
    const initializePaymentSheet = async (clientSecret) => {
        const { error } = await initPaymentSheet({
            paymentIntentClientSecret: clientSecret,
            merchantDisplayName: 'UUP Cloud',
        });
        if (error) {
            console.error('Error initializing PaymentSheet:', error);
        }
    };

    // Open the PaymentSheet
    const openPaymentSheet = async () => {
        console.log("sdsd");
        const { error } = await presentPaymentSheet();
        if (error) {
            Alert.alert(`Payment failed: ${error.message}`);
        } else {
            Alert.alert('Payment complete!');
        }
    };

    return (
        <View style={styles.container}>
            <Button title="Pay Now" onPress={openPaymentSheet} disabled={!clientSecret} />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center', // Center vertically
        alignItems: 'center', // Center horizontally
    },
});