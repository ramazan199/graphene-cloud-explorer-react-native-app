// import { createSlice } from "@reduxjs/toolkit"
// var defaultProxyPort = 5050;
// const initialState = {
//     proxy: "http://proxy.cloudservices.agency:" + defaultProxyPort
// }

// export const proxyManager = createSlice({
//     name: 'proxyManager',
//     initialState,
//     reducers: {
//         setProxy: (state, action) => {
//             state.proxy = action.payload;
//         }
//     }
// })

// export const { setProxy } = proxyManager.actions
// export default proxyManager.reducer