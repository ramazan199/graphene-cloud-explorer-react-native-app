export const colors = {
    softWhite: '#F7FAFF',
    grey: '#B0C0D0',
    darkGray: '#87949E',
    clearBlue: '#5D82F5',
    blue: '#415EB6',
    dark: '#22215B',
};
